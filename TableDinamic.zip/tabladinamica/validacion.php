<?php 

$errores = ''; 
  if (isset($_POST['agregar'])) {
  	$nombre = $_POST['nombre'];
  	$apellido = $_POST['apellido'];
  	$email = $_POST['email'];
  	$telefono = $_POST['telefono'];

  $nombre = filter_var($nombre, FILTER_SANITIZE_STRING);
} else {
	$errores .= 'Por favor agrega un nombre';
}






  }


 ?>