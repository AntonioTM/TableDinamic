
<?php 
	require_once "testserver.php";
	$conexion=conexion();
	$id=$_POST['Id'];

	$sql="DELETE from t_personas where Id='$id'";
	echo $result=sqlsrv_query($conexion,$sql);
 ?>