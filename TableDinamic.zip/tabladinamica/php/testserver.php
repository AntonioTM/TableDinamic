<?php

	function conexion(){
		$serverName="localhost";
		$connectionInfo= array("Database" => "Test", "UID" => "sa", "PWD" => "12345");
		$conexion = sqlsrv_connect($serverName, $connectionInfo);
		return $conexion;
	}

?>