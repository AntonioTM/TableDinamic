<?php 
	require_once "testserver.php";
	$conexion=conexion();
	$id=$_POST['id'];
	$n=$_POST['nombre'];
	$a=$_POST['apellido'];
	$e=$_POST['email'];
	$t=$_POST['telefono'];

	$sql="UPDATE t_personas set nombre='$n',apellido='$a',email='$e',telefono='$t' where Id='$id'";
	echo $result=sqlsrv_query($conexion,$sql);

 ?>