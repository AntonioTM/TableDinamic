<?php 

	require_once "testserver.php";
	$conexion=conexion();
	$n=$_POST['nombre'];
	$a=$_POST['apellido'];
	$e=$_POST['email'];
	$t=$_POST['telefono'];

	$sql="INSERT into t_personas (nombre,apellido,email,telefono) values ('$n','$a','$e','$t')";
	echo $result=sqlsrv_query($conexion,$sql);

 ?>