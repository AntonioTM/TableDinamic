
<?php 
	session_start();
	require_once "../php/testserver.php";
	$conexion=conexion();

 ?>
<div class="row">
	<div class="col-sm-12">
	<h2>Tabla De Registros</h2>
		<table class="table table-hover table-condensed table-bordered" id="tablaDinamicaLoad">
		<caption>
			<button class="btn btn-primary" data-toggle="modal" data-target="#modalNuevo">
				Agregar nuevo 
				<span class="glyphicon glyphicon-plus"></span>
			</button>
		</caption>
			<thead>
				<tr>
				<td>Nombre</td>
				<td>Apellido</td>
				<td>Email</td>
				<td>Telefono</td>
				<td>Editar</td>
				<td>Eliminar</td>
			</tr>
			</thead>
			 <tbody>
			<?php 

				if(isset($_SESSION['consulta'])){
					if($_SESSION['consulta'] > 0){
						$idp=$_SESSION['consulta'];
						$sql="SELECT Id,nombre,apellido,email,telefono 
						from t_personas where Id='$idp'";
					}else{
						$sql="SELECT Id,nombre,apellido,email,telefono 
						from t_personas";
					}
				}else{
					$sql="SELECT Id,nombre,apellido,email,telefono 
						from t_personas";
				}

				$result=sqlsrv_query($conexion,$sql);
				while($ver=sqlsrv_fetch_array($result, SQLSRV_FETCH_NUMERIC)){ 

					$datos=$ver[0]."||".$ver[1]."||".$ver[2]."||".$ver[3]."||".$ver[4];
			 ?>
           
			<tr>
				<td><?php echo $ver[1] ?></td>
				<td><?php echo $ver[2] ?></td>
				<td><?php echo $ver[3] ?></td>
				<td><?php echo $ver[4] ?></td>
				<td>
					<button class="btn btn-warning glyphicon glyphicon-pencil" data-toggle="modal" data-target="#modalEdicion" onclick="agregaform('<?php echo $datos ?>')">
						
					</button>
				</td>
				<td>
					<button class="btn btn-danger glyphicon glyphicon-remove" 
					onclick="preguntarSiNo('<?php echo $ver[0] ?>')">
						
					</button>
				</td>
			</tr>
			<?php 
		}
			 ?>
			 </tbody>
		</table>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		$('#tablaDinamicaLoad').DataTable();
	});
</script>